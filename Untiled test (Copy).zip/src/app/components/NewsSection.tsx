const newsItems = [
  {
    image:
      "https://cdn.prod.website-files.com/image-generation-assets/dd5f0353-4356-46b0-949e-a67e9682d518.avif",
    alt: "Community gathering",
    title: "Hier steht ein Titel zu einer News",
    desc: "Hier steht eine kurze Beschreibung zu einer Neuigkeit",
  },
  {
    image:
      "https://cdn.prod.website-files.com/image-generation-assets/d81cdbc7-040d-4f5d-9227-99dc6fb3b8aa.avif",
    alt: "Deep tissue massage",
    title: "Hier steht ein Titel zu einer News",
    desc: "Hier steht eine kurze Beschreibung zu einer Neuigkeit",
  },
  {
    image:
      "https://cdn.prod.website-files.com/image-generation-assets/fd1fd4c8-51ee-44ce-9df4-49fc82e0eba3.avif",
    alt: "Kursmaterialien",
    title: "Hier steht ein Titel zu einer News",
    desc: "Hier steht eine kurze Beschreibung zu einer Neuigkeit",
  },
];

function ArrowIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
    >
      <path
        d="M2 8H14.5M14.5 8L8.5 2M14.5 8L8.5 14"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function NewsSection() {
  return (
    <section className="w-full py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-10">
          <p className="text-[11px] tracking-[0.2em] uppercase text-primary mb-3">
            Raum für dich
          </p>
          <h2 className="mb-3">
            Neuigkeiten und Interessantes
          </h2>
          <p className="text-[16px] text-foreground/60 max-w-xl">
            Hier findest du alle Neuigkeiten unseres Tao Yin Zentrums und
            interessante Artikel zum Lesen.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {newsItems.map((item, i) => (
            <a
              key={i}
              href="#"
              className="group block"
            >
              <div className="aspect-[3/2] rounded-lg overflow-hidden mb-4">
                <img
                  src={item.image}
                  alt={item.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              </div>
              <h3 className="text-[18px] mb-2 group-hover:text-primary/70 transition-colors">
                {item.title}
              </h3>
              <p className="text-[14px] text-foreground/60 mb-3">{item.desc}</p>
              <div className="inline-flex items-center gap-2 text-[14px] text-secondary group-hover:opacity-80 transition-opacity">
                Mehr dazu
                <span className="group-hover:translate-x-1 transition-transform">
                  <ArrowIcon />
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}