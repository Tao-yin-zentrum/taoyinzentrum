import { Link } from "react-router";

const angeboteLinks = [
  { label: "Tao Yin", href: "/taoyin" },
  { label: "Qigong", href: "/qi-gong" },
  { label: "Chi Nei Tsang Massage", href: "/chi-nei-tsang" },
  { label: "Psychotherapie", href: "/psychotherapie" },
];

const serviceLinks = [
  { label: "Anfahrt & Kontakt", href: "/kontakt" },
  { label: "Impressum & Datenschutz", href: "/impressum" },
];

function InstagramIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 16 16" fill="currentColor">
      <path d="M8,1.441c2.136,0,2.389.009,3.233.047a4.419,4.419,0,0,1,1.485.276,2.472,2.472,0,0,1,.92.6,2.472,2.472,0,0,1,.6.92,4.419,4.419,0,0,1,.276,1.485c.038.844.047,1.1.047,3.233s-.009,2.389-.047,3.233a4.419,4.419,0,0,1-.276,1.485,2.644,2.644,0,0,1-1.518,1.518,4.419,4.419,0,0,1-1.485.276c-.844.038-1.1.047-3.233.047s-2.389-.009-3.233-.047a4.419,4.419,0,0,1-1.485-.276,2.472,2.472,0,0,1-.92-.6,2.472,2.472,0,0,1-.6-.92,4.419,4.419,0,0,1-.276-1.485c-.038-.844-.047-1.1-.047-3.233s.009-2.389.047-3.233a4.419,4.419,0,0,1,.276-1.485,2.472,2.472,0,0,1,.6-.92,2.472,2.472,0,0,1,.92-.6,4.419,4.419,0,0,1,1.485-.276c.844-.038,1.1-.047,3.233-.047M8,0C5.827,0,5.555.009,4.7.048A5.868,5.868,0,0,0,2.76.42a3.908,3.908,0,0,0-1.417.923A3.908,3.908,0,0,0,.42,2.76,5.868,5.868,0,0,0,.048,4.7C.009,5.555,0,5.827,0,8s.009,2.445.048,3.3A5.868,5.868,0,0,0,.42,13.24a3.908,3.908,0,0,0,.923,1.417,3.908,3.908,0,0,0,1.417.923,5.868,5.868,0,0,0,1.942.372C5.555,15.991,5.827,16,8,16s2.445-.009,3.3-.048a5.868,5.868,0,0,0,1.942-.372,4.094,4.094,0,0,0,2.34-2.34,5.868,5.868,0,0,0,.372-1.942c.039-.853.048-1.125.048-3.3s-.009-2.445-.048-3.3A5.868,5.868,0,0,0,15.58,2.76a3.908,3.908,0,0,0-.923-1.417A3.908,3.908,0,0,0,13.24.42,5.868,5.868,0,0,0,11.3.048C10.445.009,10.173,0,8,0Z" />
      <path d="M8,3.892A4.108,4.108,0,1,0,12.108,8,4.108,4.108,0,0,0,8,3.892Zm0,6.775A2.667,2.667,0,1,1,10.667,8,2.667,2.667,0,0,1,8,10.667Z" />
      <circle cx="12.27" cy="3.73" r="0.96" />
    </svg>
  );
}

export function Footer() {
  return (
    <footer className="w-full bg-[#0f2a3a] text-white">
      <div className="max-w-7xl mx-auto px-6 py-16">
        {/* Top: Heading + Emails */}
        <div className="mb-12">
          <h2 className="text-white text-[2rem] mb-4">
            In deine Mitte finden
          </h2>
          <a
            href="mailto:info@taoyin-zentrum.de?subject=Neue%20Anfrage%20Taoyin%20Zentrum"
            className="block text-[1.5rem] text-white/70 hover:text-white transition-colors mb-1"
            style={{ fontFamily: "'Petrona', Georgia, serif", fontStyle: "italic" }}
          >
            info@taoyin-zentrum.de
          </a>
          <a
            href="mailto:info@estela-fuchs.com?subject=Neue%20Therapieanfrage"
            className="block text-[1.5rem] text-white/70 hover:text-white transition-colors"
            style={{ fontFamily: "'Petrona', Georgia, serif", fontStyle: "italic" }}
          >
            info@estela-fuchs.com
          </a>
        </div>

        {/* Middle: Description + Links */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
          <p className="text-white/50 text-[16px] leading-relaxed">
            Raum für Achtsamkeit & Balance
          </p>
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h3 className="text-[13px] tracking-[0.1em] uppercase text-white/40 mb-4">
                Angebote
              </h3>
              <ul className="space-y-2.5">
                {angeboteLinks.map((link) => (
                  <li key={link.href}>
                    <Link
                      to={link.href}
                      className="text-[15px] text-white/60 hover:text-white transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[13px] tracking-[0.1em] uppercase text-white/40 mb-4">
                Service
              </h3>
              <ul className="space-y-2.5">
                {serviceLinks.map((link) => (
                  <li key={link.href}>
                    <Link
                      to={link.href}
                      className="text-[15px] text-white/60 hover:text-white transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom: Logo + Social */}
        <div className="border-t border-white/10 pt-8 flex items-center justify-between">
          <Link to="/">
            <img
              src="https://cdn.prod.website-files.com/6890d61524a7dba397203fde/6890d8b72344be05aef5a64a_tao_logo_white.png"
              alt="Taoyin Zentrum"
              className="h-12 w-auto opacity-70 hover:opacity-100 transition-opacity"
              loading="lazy"
            />
          </Link>
          <a
            href="https://www.instagram.com/taoyin_zentrum/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/50 hover:text-white transition-colors"
            aria-label="Instagram"
          >
            <InstagramIcon />
          </a>
        </div>
      </div>
    </footer>
  );
}